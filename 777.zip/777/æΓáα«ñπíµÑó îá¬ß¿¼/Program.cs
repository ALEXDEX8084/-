﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR17_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Практическая работа 15-16");
            Console.WriteLine("Выполнил Стародубцев Максим");
            Console.WriteLine("Вариант 2");
            Console.WriteLine();

             List<STUDENT> students = new List<STUDENT>();

        StreamReader streamReader = new StreamReader(@"input.txt", Encoding.Default);
            while (!streamReader.EndOfStream)
            {
                streamReader.ReadLine();
                {
                    string line = streamReader.ReadLine();
                    string[] items = line.Split(',');
                    STUDENT student = new STUDENT()
                    {
                        Name = items[0].Trim(),
                        Group = items[1].Trim(),
                        Math = int.Parse(items[2].Trim()),
                        History = int.Parse(items[3].Trim()),
                        Physics = int.Parse(items[4].Trim()),
                        Obzh = int.Parse(items[5].Trim()),
                        French = int.Parse(items[6].Trim())
                    };
                    students.Add(student);




                    if (student.Math == 3 || student.Math == 4)
                    {
                        Console.WriteLine(student.PrintInfo());
                        student.Save();
                    }

                    else if (student.History == 3 || student.History == 4)
                    {
                        Console.WriteLine(student.PrintInfo());
                        student.Save();
                    }

                    else if (student.Physics == 3 || student.Physics == 4)
                    {
                        Console.WriteLine(student.PrintInfo());
                        student.Save();
                    }

                    else if (student.Obzh == 3 || student.Obzh == 4)
                    {
                        Console.WriteLine(student.PrintInfo());
                        student.Save();
                    }

                    else if (student.French == 3 || student.French == 4)
                    {
                        Console.WriteLine(student.PrintInfo());
                        student.Save();
                    }

                    else
                    {
                        Console.WriteLine("нет студента с оценкой 3 или 4");
                    }



                    Console.ReadKey();
                }
            }
        }
    }
}

