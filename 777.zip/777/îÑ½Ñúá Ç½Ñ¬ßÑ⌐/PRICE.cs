﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace PR17
{
    class PRICE
    {
        //поля
        string name;
        string mname;
        double price;
        int count;
        double summa;

        //свойства
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Mname
        {
            get { return mname; }
            set { mname = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        public int Count
        {
            get { return count; }
            set { count = value; }
        }
        //конструкторы
        public void Goods()
        {
            name = "";
            mname = "";
            price = 0.0;
            count = 0;
        }
        public void Goods(string name, string mname, double price, int count)
        {
            this.name = name;
            this.mname = mname;
            this.price = price;
            this.count = count;
            this.summa = count * price;
        }
        public string PrintInfo()
        {
            return $" Название товара {name} " +
                $"Цена: {price} " +
                $" Название магазина: {mname} " +
                $"Количество товара: {count}" + $"Стоимость товаров в магазине {summa} ";
        }
        public void Save()
        {
            StreamWriter sr = new StreamWriter(@"Result.txt", true);
            sr.WriteLine($"{name};{price};{mname};{count};{summa}");
            sr.Close();
        }
        public void InputFromFile(StreamReader sr)
        {

            string input = sr.ReadLine();
            string[] info = input.Split(';');
            name = info[0];
            price = int.Parse(info[1]);
            mname = info[2];
            count = int.Parse(info[3]);
            summa = int.Parse(info[4]);
        }
    }
}
