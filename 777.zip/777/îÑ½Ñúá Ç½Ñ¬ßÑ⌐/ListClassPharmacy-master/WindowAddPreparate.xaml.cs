﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ListClass.Classes;

namespace ListClass
{
    /// <summary>
    /// Логика взаимодействия для WindowAddPreparate.xaml
    /// </summary>
    public partial class WindowAddPreparate : Window
    {
        public WindowAddPreparate()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Привязка полей для добавления
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddPreparate_Click(object sender, RoutedEventArgs e)
        {
            Goods good = new Goods()
            {
                Name = TxbName.Text,
                Mname = TxbCount.Text,
                Price = double.Parse(TxbPrice.Text),
                Count = int.Parse(TxbMonth.Text)
            };
            ConnectHelper.goods.Add(good);
            this.Close();
        }
    }
}
