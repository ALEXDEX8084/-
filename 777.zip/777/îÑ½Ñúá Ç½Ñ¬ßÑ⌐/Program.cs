﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR17
{
    class Program
    {
        static void Main(string[] args)
        {
            List<PRICE> good = new List<PRICE>();
            StreamReader streamReader = new StreamReader(@"ListPreparates.txt.txt", Encoding.Default);
            while (!streamReader.EndOfStream)
            {
                streamReader.ReadLine();

            }
            string line = streamReader.ReadLine();
            string[] items = line.Split(';');
            PRICE goods = new PRICE()
            {
                Name = items[0].Trim(),
                Count = int.Parse(items[1].Trim()),
                Price = double.Parse(items[2].Trim()),
                 Mname = items[3].Trim()
            };
            good.Add(goods);
        }
    }
}
    

