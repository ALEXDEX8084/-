﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadanijeList
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            Console.WriteLine("Выполнили студенты группы ИСП.20А");
            Console.WriteLine("Мелега Алексей и Стародубцев Максим");
            Console.WriteLine("Задание №1");
            List<string> pokupki = new List<string>();
            Console.WriteLine("Введите количество покупок");
            n = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите Покупки");
            EnterList(n, pokupki);
            Console.WriteLine("Вывод");
            PrintList(pokupki);
            Console.ReadKey();
            pokupki.Sort();
            Console.WriteLine("От А до Я: ");
            PrintList(pokupki);
            Console.WriteLine("От Я до А: ");
            pokupki.Reverse();
            PrintList(pokupki);
            Console.WriteLine("Задание №2");
            List<string> strings = new List<string>();
            Console.WriteLine("Введите количество строк");
            n = int.Parse(Console.ReadLine());
            EnterList(n, strings);
            Console.WriteLine("Введите искомое слово");
            string p = Console.ReadLine();
            for (int i = 0; i < n; i++)
            {
                if (strings[i].Contains(p))
                {
                    Console.WriteLine(strings[i]);
                }
            }
            Console.ReadKey();
            Console.WriteLine("Задание №3");
            List<string> strings1 = new List<string>();
            Console.WriteLine("Введите количество строк");
            n = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите номер буквы в слове");
            int number = int.Parse(Console.ReadLine());
            number -= 1;
            string word = ("");
            Console.WriteLine("Введите слово: ");
            EnterList(n, strings1);
            foreach (string word1 in strings1)
            {
                word += word1[number];
            }
            Console.WriteLine("Результат: ");
            Console.WriteLine(word);
            Console.ReadKey();
            Console.WriteLine("Задание №4");
            Console.WriteLine("Введите количество строк");
            n = int.Parse(Console.ReadLine());
            List<string> strings2 = new List<string>();
            Console.WriteLine("Введите строки: ");
            EnterList(n, strings2);
            Console.WriteLine("Введите количество частей объявления: ");
            int howmuchstrings = int.Parse(Console.ReadLine());
            List<int> necesparts = new List<int>();
            Console.WriteLine("Введите необходимые строки: ");
            EnterListint(howmuchstrings, necesparts);
            Console.WriteLine("Результат: ");
            for (int i = 0; i < n; i++)

            {
                if (necesparts.Contains(i))
                {
                    Console.WriteLine(strings2[i - 1]);
                }

            }
            Console.ReadKey();




            Console.WriteLine("Задание №5");
            Console.WriteLine("Введите количество клиентов банка: ");
            int N = int.Parse(Console.ReadLine());
            List<int> listclients = new List<int>(N);
            Console.WriteLine("Введите вложения");
            EnterListint(N, listclients);
            Console.WriteLine("Исходные вложения: ");
            PrintListint(listclients);
            Console.WriteLine("Накопления через год: ");
            foreach (int l in listclients)
            {
                Console.WriteLine(l * 3);
            }
            Console.ReadKey();
        }

        private static void EnterList(int n, List<string> strings)
        {
            for (int i = 0; i < n; i++)
            {
                string v = Console.ReadLine();
                strings.Add(v);
            }
        }
        private static void EnterListint(int n, List<int> strings)
        {
            for (int i = 0; i < n; i++)
            {
                int v = int.Parse(Console.ReadLine());
                strings.Add(v);
            }
        }

        private static void PrintList(List<string> pokupki)
        {
            foreach (var item in pokupki)
            {
                Console.WriteLine(item);
            }
        }
        private static void PrintListint(List<int> pokupki)
        {
            foreach (var item in pokupki)
            {
                Console.WriteLine(item);
            }
        }
    }
}
