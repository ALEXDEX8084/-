﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR17
{
    class Program
    {
        static void Main(string[] args)
        {
            List<PRICE> good = new List<PRICE>();
            StreamReader streamReader = new StreamReader(@"ListPreparates.txt.txt", Encoding.UTF8);
            while (!streamReader.EndOfStream)
            {
                streamReader.ReadLine();

                string line = streamReader.ReadLine();
                string[] items = streamReader.ReadLine().Split(';');
                PRICE goods = new PRICE()
                {
                    Name = items[0].Trim(),
                    Count = int.Parse(items[1].Trim()),
                    Price = double.Parse(items[2].Trim()),
                    Mname = items[3].Trim()
                };
                good.Add(goods);
            }
            Console.Write("Введите количество товаров: N=");
            int N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N; i++)
            {
                Console.WriteLine();
                Console.WriteLine($"Заполните данные товара №{i + 1}.");
                Console.Write("Введите название товара: ");
                string name = Console.ReadLine();
                Console.Write("Введите название магазина: ");
                string mname = Console.ReadLine();
                Console.Write("Введите Цену: ");
                double price = Convert.ToDouble(Console.ReadLine());
                Console.Write("Введите количество: ");
                int count = Convert.ToInt32(Console.ReadLine());
                PRICE goods = new PRICE()
                {
                    Name =name,
                    Mname = mname,
                    Price = price,
                    Count = count
                };
                good.Add(goods);
            }
            Console.WriteLine();
            for (int j = 0; j < good.Count; j++)
            {
                Console.WriteLine($"Данные товара №{j + 1}.");
                Console.WriteLine(good[j].PrintInfo());
            }

            for (int i = 0; i < good.Count; i++)
            {
                good[i].Save();
            }
            Console.ReadKey();
            Console.Write("Введите название товара: ");
            string search_experience = Console.ReadLine();

            Console.ReadKey();
        }
               public static void Search(List<PRICE> goods, string search_name)
        {
            bool flag = false;
            for (int i = 0; i < goods.Count; i++)
            {
                if (goods[i].Name == search_name)
                {
                    flag = true;
                    Console.WriteLine(goods[i].PrintInfo());
                }
            }
            if (!flag) Console.WriteLine("Товар не обнаружен!");
        }
    }
}
    

